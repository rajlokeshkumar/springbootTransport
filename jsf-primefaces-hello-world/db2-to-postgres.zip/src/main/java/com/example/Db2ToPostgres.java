import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Db2ToPostgres {
    private static final Logger logger = LoggerFactory.getLogger(Db2ToPostgres.class);
    private static final String DB2_URL = "jdbc:db2://your_db2_host:50000/YOUR_DB";
    private static final String DB2_USER = "your_db2_user";
    private static final String DB2_PASSWORD = "your_db2_password";

    private static final String POSTGRES_URL = "jdbc:postgresql://your_pg_host:5432/YOUR_DB";
    private static final String POSTGRES_USER = "your_pg_user";
    private static final String POSTGRES_PASSWORD = "your_pg_password";

    private static final int THREAD_COUNT = 5;
    private static final int BATCH_SIZE = 1000;
    private static final int FETCH_LIMIT = 500000;
    
    private static HikariDataSource db2DataSource;
    private static HikariDataSource pgDataSource;
    
    private static final List<String> TABLE_NAMES = Arrays.asList("table1", "table2", "table3", "table4", "table5");

    public static void main(String[] args) {
        setupConnectionPools();
        ExecutorService executor = Executors.newFixedThreadPool(THREAD_COUNT);
        
        for (String tableName : TABLE_NAMES) {
            executor.execute(() -> processTable(tableName));
        }
        
        executor.shutdown();
    }
    
    private static void processTable(String tableName) {
        int totalFetched = 0;
        int totalInserted = 0;
        LocalDateTime startTime = LocalDateTime.now();
        
        try (Connection pgConn = pgDataSource.getConnection();
             Statement countStmt = pgConn.createStatement()) {
            ResultSet countResult = countStmt.executeQuery("SELECT COUNT(*) FROM " + tableName);
            int existingCount = 0;
            if (countResult.next()) {
                existingCount = countResult.getInt(1);
            }
            logger.info("Table: {} | Existing Rows: {} | Start Time: {}", tableName, existingCount, startTime);
            
            try (Statement deleteStmt = pgConn.createStatement()) {
                deleteStmt.executeUpdate("DELETE FROM " + tableName);
                pgConn.commit();
            }
        } catch (SQLException e) {
            logger.error("Error processing table {}", tableName, e);
        }
    }
    
    private static void setupConnectionPools() {
        HikariConfig db2Config = new HikariConfig();
        db2Config.setJdbcUrl(DB2_URL);
        db2Config.setUsername(DB2_USER);
        db2Config.setPassword(DB2_PASSWORD);
        db2Config.setMaximumPoolSize(THREAD_COUNT);
        db2DataSource = new HikariDataSource(db2Config);

        HikariConfig pgConfig = new HikariConfig();
        pgConfig.setJdbcUrl(POSTGRES_URL);
        pgConfig.setUsername(POSTGRES_USER);
        pgConfig.setPassword(POSTGRES_PASSWORD);
        pgConfig.setMaximumPoolSize(THREAD_COUNT);
        pgDataSource = new HikariDataSource(pgConfig);
    }
}

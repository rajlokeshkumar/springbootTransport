package com.example.multipackagedemo.packagethree;

public class Class5 {

    public void method1() {
        System.out.println("Class5 - method1 in packagethree");
    }

    public void method2() {
        System.out.println("Class5 - method2 in packagethree");
    }

    public void method3() {
        System.out.println("Class5 - method3 in packagethree");
    }

    public void method4() {
        System.out.println("Class5 - method4 in packagethree");
    }

    public void method5() {
        System.out.println("Class5 - method5 in packagethree");
    }

    public void method6() {
        System.out.println("Class5 - method6 in packagethree");
    }

    public void method7() {
        System.out.println("Class5 - method7 in packagethree");
    }

    public void method8() {
        System.out.println("Class5 - method8 in packagethree");
    }

    public void method9() {
        System.out.println("Class5 - method9 in packagethree");
    }

    public void method10() {
        System.out.println("Class5 - method10 in packagethree");
    }

    public void runAllMethods() {
        System.out.println("Class5 filler line 1");
        System.out.println("Class5 filler line 2");
        System.out.println("Class5 filler line 3");
        System.out.println("Class5 filler line 4");
        System.out.println("Class5 filler line 5");
        System.out.println("Class5 filler line 6");
        System.out.println("Class5 filler line 7");
        System.out.println("Class5 filler line 8");
        System.out.println("Class5 filler line 9");
        System.out.println("Class5 filler line 10");
        System.out.println("Class5 filler line 11");
        System.out.println("Class5 filler line 12");
        System.out.println("Class5 filler line 13");
        System.out.println("Class5 filler line 14");
        System.out.println("Class5 filler line 15");
        System.out.println("Class5 filler line 16");
        System.out.println("Class5 filler line 17");
        System.out.println("Class5 filler line 18");
        System.out.println("Class5 filler line 19");
        System.out.println("Class5 filler line 20");
        System.out.println("Class5 filler line 21");
        System.out.println("Class5 filler line 22");
        System.out.println("Class5 filler line 23");
        System.out.println("Class5 filler line 24");
        System.out.println("Class5 filler line 25");
        System.out.println("Class5 filler line 26");
        System.out.println("Class5 filler line 27");
        System.out.println("Class5 filler line 28");
        System.out.println("Class5 filler line 29");
        System.out.println("Class5 filler line 30");
        System.out.println("Class5 filler line 31");
        System.out.println("Class5 filler line 32");
        System.out.println("Class5 filler line 33");
        System.out.println("Class5 filler line 34");
        System.out.println("Class5 filler line 35");
        System.out.println("Class5 filler line 36");
        System.out.println("Class5 filler line 37");
        System.out.println("Class5 filler line 38");
        System.out.println("Class5 filler line 39");
        System.out.println("Class5 filler line 40");
        System.out.println("Class5 filler line 41");
        System.out.println("Class5 filler line 42");
        System.out.println("Class5 filler line 43");
        System.out.println("Class5 filler line 44");
        System.out.println("Class5 filler line 45");
        System.out.println("Class5 filler line 46");
        System.out.println("Class5 filler line 47");
        System.out.println("Class5 filler line 48");
        System.out.println("Class5 filler line 49");
        System.out.println("Class5 filler line 50");
        System.out.println("Class5 filler line 51");
        System.out.println("Class5 filler line 52");
        System.out.println("Class5 filler line 53");
        System.out.println("Class5 filler line 54");
        System.out.println("Class5 filler line 55");
        System.out.println("Class5 filler line 56");
        System.out.println("Class5 filler line 57");
        System.out.println("Class5 filler line 58");
        System.out.println("Class5 filler line 59");
        System.out.println("Class5 filler line 60");
        System.out.println("Class5 filler line 61");
        System.out.println("Class5 filler line 62");
        System.out.println("Class5 filler line 63");
        System.out.println("Class5 filler line 64");
        System.out.println("Class5 filler line 65");
        System.out.println("Class5 filler line 66");
        System.out.println("Class5 filler line 67");
        System.out.println("Class5 filler line 68");
        System.out.println("Class5 filler line 69");
        System.out.println("Class5 filler line 70");
        System.out.println("Class5 filler line 71");
        System.out.println("Class5 filler line 72");
        System.out.println("Class5 filler line 73");
        System.out.println("Class5 filler line 74");
        System.out.println("Class5 filler line 75");
        System.out.println("Class5 filler line 76");
        System.out.println("Class5 filler line 77");
        System.out.println("Class5 filler line 78");
        System.out.println("Class5 filler line 79");
        System.out.println("Class5 filler line 80");
        System.out.println("Class5 filler line 81");
        System.out.println("Class5 filler line 82");
        System.out.println("Class5 filler line 83");
        System.out.println("Class5 filler line 84");
        System.out.println("Class5 filler line 85");
        System.out.println("Class5 filler line 86");
        System.out.println("Class5 filler line 87");
        System.out.println("Class5 filler line 88");
        System.out.println("Class5 filler line 89");
        System.out.println("Class5 filler line 90");
        System.out.println("Class5 filler line 91");
        System.out.println("Class5 filler line 92");
        System.out.println("Class5 filler line 93");
        System.out.println("Class5 filler line 94");
        System.out.println("Class5 filler line 95");
        System.out.println("Class5 filler line 96");
        System.out.println("Class5 filler line 97");
        System.out.println("Class5 filler line 98");
        System.out.println("Class5 filler line 99");
        System.out.println("Class5 filler line 100");
        System.out.println("Class5 filler line 101");
        System.out.println("Class5 filler line 102");
        System.out.println("Class5 filler line 103");
        System.out.println("Class5 filler line 104");
        System.out.println("Class5 filler line 105");
        System.out.println("Class5 filler line 106");
        System.out.println("Class5 filler line 107");
        System.out.println("Class5 filler line 108");
        System.out.println("Class5 filler line 109");
        System.out.println("Class5 filler line 110");
        System.out.println("Class5 filler line 111");
        System.out.println("Class5 filler line 112");
        System.out.println("Class5 filler line 113");
        System.out.println("Class5 filler line 114");
        System.out.println("Class5 filler line 115");
        System.out.println("Class5 filler line 116");
        System.out.println("Class5 filler line 117");
        System.out.println("Class5 filler line 118");
        System.out.println("Class5 filler line 119");
        System.out.println("Class5 filler line 120");
        System.out.println("Class5 filler line 121");
        System.out.println("Class5 filler line 122");
        System.out.println("Class5 filler line 123");
        System.out.println("Class5 filler line 124");
        System.out.println("Class5 filler line 125");
        System.out.println("Class5 filler line 126");
        System.out.println("Class5 filler line 127");
        System.out.println("Class5 filler line 128");
        System.out.println("Class5 filler line 129");
        for(int i=1;i<=10;i++) {
            System.out.println("Class5 running loop " + i);
        }
    }
}

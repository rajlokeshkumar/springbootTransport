package com.example.multipackagedemo;

public class MainApp {
    public static void main(String[] args) {
        System.out.println("Starting MultiPackage Demo...");
        new com.example.multipackagedemo.packageone.Class1().runAllMethods();
        new com.example.multipackagedemo.packageone.Class2().runAllMethods();
        new com.example.multipackagedemo.packageone.Class3().runAllMethods();
        new com.example.multipackagedemo.packageone.Class4().runAllMethods();
        new com.example.multipackagedemo.packageone.Class5().runAllMethods();
        new com.example.multipackagedemo.packagetwo.Class1().runAllMethods();
        new com.example.multipackagedemo.packagetwo.Class2().runAllMethods();
        new com.example.multipackagedemo.packagetwo.Class3().runAllMethods();
        new com.example.multipackagedemo.packagetwo.Class4().runAllMethods();
        new com.example.multipackagedemo.packagetwo.Class5().runAllMethods();
        new com.example.multipackagedemo.packagethree.Class1().runAllMethods();
        new com.example.multipackagedemo.packagethree.Class2().runAllMethods();
        new com.example.multipackagedemo.packagethree.Class3().runAllMethods();
        new com.example.multipackagedemo.packagethree.Class4().runAllMethods();
        new com.example.multipackagedemo.packagethree.Class5().runAllMethods();

        System.out.println("All classes executed.");
    }
}
